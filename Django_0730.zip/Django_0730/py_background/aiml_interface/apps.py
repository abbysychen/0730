from django.apps import AppConfig


class AimlInterfaceConfig(AppConfig):
    name = 'aiml_interface'
